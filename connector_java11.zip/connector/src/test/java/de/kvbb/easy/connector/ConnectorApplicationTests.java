package de.kvbb.easy.connector;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConnectorApplicationTests {

	@Test
	void contextLoads() {
	}

}
